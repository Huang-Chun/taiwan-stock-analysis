# 台股供應鏈研究框架

## 這是什麼

把先前在 Claude.ai 這個 project 裡逐步建立的「六層供應鏈分析框架」定型成一個可攜的方法論套件，讓 Claude Code 可以直接讀取、套用、產出符合既有格式的分析內容。

## 資料夾結構

```
CLAUDE.md                          ← Claude Code 進入這個資料夾時會自動讀取的專案指令
framework/
  six-layer-framework.md           ← 六層供應鏈骨架
  moat-classification.md           ← 護城河分類系統
  causal-lines-framework.md        ← 三條因果線框架
  customer-relationship-typology.md← 客戶關係類型學
templates/
  industry-map-template.md         ← 新產業別分析輸出格式
  stock-business-template.md       ← 個股商業分析（慢更新）
  stock-financial-tracking-template.md ← 個股財務追蹤（快更新）
coverage/
  coverage-status.md               ← 目前已建置/待建置的產業與個股快照
```

## 怎麼用

1. 把這個資料夾放到你要用 Claude Code 工作的專案路徑下（或直接在這個資料夾裡開 Claude Code）
2. Claude Code 啟動時會自動讀 `CLAUDE.md`，取得框架與工作流程
3. 跟它說「幫我分析 XX 產業」或「幫我分析 OOOO 這檔股票」，它會套用對應模板產出內容
4. 產出的 markdown 內容可以直接貼回 Notion，或請它透過 Notion MCP 直接寫入（如果你在 Claude Code 裡也設定了 Notion MCP）

## 維護提醒

- `coverage/coverage-status.md` 是快照，不是即時同步。真正的最新狀態以 Notion 為準；每次做新分析前，建議先跟 Claude Code 說明 Notion 上是否有更新，避免它用過期的覆蓋範圍判斷重工或漏工。
- 框架本身（`framework/` 底下四個檔案）是這個專案的核心資產，之後如果分析方法論有調整（例如新增第四條因果線、或護城河分類系統要再細分），直接改這幾個檔案，所有未來分析都會自動套用新版本。
- 這套框架架構本身也是為了未來遷移到自建網站而設計的可攜格式，所以模板刻意用純 markdown + table，不綁定 Notion 專屬語法。
